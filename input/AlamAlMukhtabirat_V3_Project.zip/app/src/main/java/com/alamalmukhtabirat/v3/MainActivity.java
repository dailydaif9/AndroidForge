package com.alamalmukhtabirat.v3;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private StoreDb db;
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        db = new StoreDb();
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Store");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class StoreDb extends SQLiteOpenHelper {
        StoreDb() { super(MainActivity.this, "alam_store_v3.db", null, 1); }
        @Override public void onCreate(SQLiteDatabase d) {
            d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,category TEXT,unit TEXT,qty REAL DEFAULT 0,min_qty REAL DEFAULT 0,lot TEXT,expiry TEXT,buy REAL DEFAULT 0,sell REAL DEFAULT 0)");
            d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,notes TEXT)");
            d.execSQL("CREATE TABLE suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,notes TEXT)");
        }
        @Override public void onUpgrade(SQLiteDatabase d,int oldV,int newV) {}
    }

    private class Bridge {
        @JavascriptInterface public String list(String table) {
            if (!table.equals("items") && !table.equals("customers") && !table.equals("suppliers")) return "[]";
            JSONArray a = new JSONArray();
            Cursor c = db.getReadableDatabase().rawQuery("SELECT * FROM " + table + " ORDER BY id DESC", null);
            try {
                while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    for (int i=0;i<c.getColumnCount();i++) {
                        String key = c.getColumnName(i);
                        int type = c.getType(i);
                        Object val = type == Cursor.FIELD_TYPE_INTEGER ? c.getLong(i) :
                            type == Cursor.FIELD_TYPE_FLOAT ? c.getDouble(i) :
                            type == Cursor.FIELD_TYPE_NULL ? JSONObject.NULL : c.getString(i);
                        o.put(key,val);
                    }
                    a.put(o);
                }
            } catch(Exception ignored) {} finally { c.close(); }
            return a.toString();
        }

        @JavascriptInterface public boolean addItem(String name,String code,String category,String unit,
                String qty,String minQty,String lot,String expiry,String buy,String sell) {
            if (name == null || name.trim().isEmpty()) return false;
            ContentValues v = new ContentValues();
            v.put("name",name); v.put("code",code); v.put("category",category); v.put("unit",unit);
            v.put("qty",number(qty)); v.put("min_qty",number(minQty)); v.put("lot",lot); v.put("expiry",expiry);
            v.put("buy",number(buy)); v.put("sell",number(sell));
            return db.getWritableDatabase().insert("items",null,v) != -1;
        }

        @JavascriptInterface public boolean addPerson(String table,String name,String phone,String address,String notes) {
            if ((!table.equals("customers") && !table.equals("suppliers")) || name == null || name.trim().isEmpty()) return false;
            ContentValues v = new ContentValues();
            v.put("name",name); v.put("phone",phone); v.put("address",address); v.put("notes",notes);
            return db.getWritableDatabase().insert(table,null,v) != -1;
        }

        @JavascriptInterface public String stats() {
            SQLiteDatabase d = db.getReadableDatabase();
            JSONObject o = new JSONObject();
            try {
                o.put("items",count(d,"items")); o.put("customers",count(d,"customers")); o.put("suppliers",count(d,"suppliers"));
                o.put("low",d.rawQuery("SELECT id FROM items WHERE qty<=min_qty",null).getCount());
                Cursor c=d.rawQuery("SELECT COALESCE(SUM(qty*buy),0) FROM items",null);
                if(c.moveToFirst()) o.put("stockValue",c.getDouble(0)); c.close();
            } catch(Exception ignored) {}
            return o.toString();
        }
        private int count(SQLiteDatabase d,String t) {
            Cursor c=d.rawQuery("SELECT COUNT(*) FROM "+t,null); int n=0;
            if(c.moveToFirst()) n=c.getInt(0); c.close(); return n;
        }
        private double number(String s) { try { return Double.parseDouble(s); } catch(Exception e) { return 0; } }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
