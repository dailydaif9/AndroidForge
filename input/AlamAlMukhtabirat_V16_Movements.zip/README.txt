Alam Al Mukhtabirat V16 - Unified Movements Log
Based on V15 dashboard. Adds a unified movements page for sales, purchases, receipts, payments, free samples, stock issue orders, and quotations, with search and type/date filters. Existing sections and built-in logo are retained.
Build APK using the existing AndroidForge workflow.
