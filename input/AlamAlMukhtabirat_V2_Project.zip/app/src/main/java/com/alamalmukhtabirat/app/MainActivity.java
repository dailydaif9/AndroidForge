package com.alamalmukhtabirat.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import android.database.Cursor;

public class MainActivity extends Activity {
    private WebView webView;
    private StoreDb db;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        db = new StoreDb(this);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AppBridge(), "NativeStore");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AppBridge {
        @JavascriptInterface public String getItems() { return db.getRows("items").toString(); }
        @JavascriptInterface public String getCustomers() { return db.getRows("customers").toString(); }
        @JavascriptInterface public String getSuppliers() { return db.getRows("suppliers").toString(); }
        @JavascriptInterface public String getDashboard() { return db.getDashboard().toString(); }

        @JavascriptInterface public String addItem(String raw) {
            try {
                JSONObject j = new JSONObject(raw);
                ContentValues v = new ContentValues();
                v.put("name", j.optString("name").trim());
                v.put("sku", j.optString("sku").trim());
                v.put("category", j.optString("category").trim());
                v.put("unit", j.optString("unit", "قطعة").trim());
                v.put("lot", j.optString("lot").trim());
                v.put("expiry", j.optString("expiry").trim());
                v.put("qty", j.optDouble("qty", 0));
                v.put("min_qty", j.optDouble("min_qty", 0));
                v.put("buy_price", j.optDouble("buy_price", 0));
                v.put("sell_price", j.optDouble("sell_price", 0));
                if (v.getAsString("name").isEmpty()) return error("اسم الصنف مطلوب");
                long id = db.getWritableDatabase().insert("items", null, v);
                return result(id > 0, id > 0 ? "تم حفظ الصنف" : "تعذر حفظ الصنف");
            } catch (Exception e) { return error("بيانات غير صحيحة"); }
        }

        @JavascriptInterface public String addCustomer(String raw) { return addParty(raw, "customers"); }
        @JavascriptInterface public String addSupplier(String raw) { return addParty(raw, "suppliers"); }

        private String addParty(String raw, String table) {
            try {
                JSONObject j = new JSONObject(raw);
                String name = j.optString("name").trim();
                if (name.isEmpty()) return error("الاسم مطلوب");
                ContentValues v = new ContentValues();
                v.put("name", name);
                v.put("phone", j.optString("phone").trim());
                v.put("address", j.optString("address").trim());
                v.put("notes", j.optString("notes").trim());
                long id = db.getWritableDatabase().insert(table, null, v);
                return result(id > 0, id > 0 ? "تم الحفظ بنجاح" : "تعذر الحفظ");
            } catch (Exception e) { return error("بيانات غير صحيحة"); }
        }

        private String result(boolean ok, String msg) {
            JSONObject o = new JSONObject();
            try { o.put("ok", ok); o.put("message", msg); } catch (Exception ignored) {}
            return o.toString();
        }
        private String error(String msg) { return result(false, msg); }
    }

    private static class StoreDb extends SQLiteOpenHelper {
        StoreDb(Context c) { super(c, "alam_store.db", null, 1); }
        @Override public void onCreate(SQLiteDatabase d) {
            d.execSQL("CREATE TABLE items (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, sku TEXT, category TEXT, unit TEXT, lot TEXT, expiry TEXT, qty REAL DEFAULT 0, min_qty REAL DEFAULT 0, buy_price REAL DEFAULT 0, sell_price REAL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
            d.execSQL("CREATE TABLE customers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, address TEXT, notes TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
            d.execSQL("CREATE TABLE suppliers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, address TEXT, notes TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        }
        @Override public void onUpgrade(SQLiteDatabase d, int oldV, int newV) {}

        JSONArray getRows(String table) {
            JSONArray a = new JSONArray();
            Cursor c = getReadableDatabase().rawQuery("SELECT * FROM " + table + " ORDER BY id DESC", null);
            try {
                while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    for (int i=0; i<c.getColumnCount(); i++) {
                        try {
                            int type = c.getType(i);
                            if (type == Cursor.FIELD_TYPE_INTEGER) o.put(c.getColumnName(i), c.getLong(i));
                            else if (type == Cursor.FIELD_TYPE_FLOAT) o.put(c.getColumnName(i), c.getDouble(i));
                            else if (type == Cursor.FIELD_TYPE_NULL) o.put(c.getColumnName(i), JSONObject.NULL);
                            else o.put(c.getColumnName(i), c.getString(i));
                        } catch (Exception ignored) {}
                    }
                    a.put(o);
                }
            } finally { c.close(); }
            return a;
        }

        JSONObject getDashboard() {
            JSONObject o = new JSONObject();
            SQLiteDatabase d = getReadableDatabase();
            try {
                o.put("items", scalar(d, "SELECT COUNT(*) FROM items"));
                o.put("customers", scalar(d, "SELECT COUNT(*) FROM customers"));
                o.put("suppliers", scalar(d, "SELECT COUNT(*) FROM suppliers"));
                o.put("low_stock", scalar(d, "SELECT COUNT(*) FROM items WHERE qty <= min_qty"));
                o.put("stock_value", scalarDouble(d, "SELECT COALESCE(SUM(qty*buy_price),0) FROM items"));
            } catch (Exception ignored) {}
            return o;
        }
        long scalar(SQLiteDatabase d, String q) {
            Cursor c=d.rawQuery(q,null); try { return c.moveToFirst()?c.getLong(0):0; } finally { c.close(); }
        }
        double scalarDouble(SQLiteDatabase d, String q) {
            Cursor c=d.rawQuery(q,null); try { return c.moveToFirst()?c.getDouble(0):0; } finally { c.close(); }
        }
    }
}
