عالم المختبرات للمستلزمات الطبية — V22.0

هذه نسخة مشروع محسّنة مبنية على V21.
معرّف التطبيق الجديد: com.alamalmukhtabirat.v6.v22

مهم: تم تغيير معرّف التطبيق عمداً حتى يمكن تثبيت V22 بجانب التطبيق السابق دون تعارض توقيع أو استبداله. لذلك سيعمل V22 بقاعدة بيانات مستقلة وفارغة، ولن تنتقل بيانات V21 تلقائياً. احتفظ بالتطبيق القديم ولا تحذفه.

تتضمن النسخة تحسيناً في تجهيز PDF للمشاركة، مع انتظار تحميل الصور والخطوط وقياس المحتوى قبل تقسيمه إلى صفحات. كما تحتفظ بالوظائف الموجودة في V21 مثل تعديل/حذف الفواتير والسندات، الشعار، كشف الحساب، واقتراحات البحث.

يجب بناء APK عبر AndroidForge/GitHub Actions ثم تثبيته كتطبيق مستقل. لم يتم بناء APK داخل هذه الحزمة.


V24.0: Added item unit to invoice lines and invoice print/PDF. Database migration adds invoice_lines.unit and backfills units from existing item records without deleting existing data.

V25.0: Clean AndroidManifest.xml without a package attribute; versionCode/versionName advanced for this build attempt.
