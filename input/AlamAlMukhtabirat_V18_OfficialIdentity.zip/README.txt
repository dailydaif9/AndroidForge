Alam Al Mukhtabirat V17 - Active Home Dashboard Shortcuts
Based on V16. Home dashboard tiles and summary figures now navigate to their corresponding existing sections. Added direct home shortcuts for quotations, free samples, stock issue orders, and the unified movements log. Existing modules and built-in logo are retained. Employee management remains unimplemented and is not presented as an active module.
Build APK using the existing AndroidForge workflow.
