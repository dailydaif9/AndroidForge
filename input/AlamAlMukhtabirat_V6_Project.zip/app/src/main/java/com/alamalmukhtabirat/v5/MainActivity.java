package com.alamalmukhtabirat.v6;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashMap;

public class MainActivity extends Activity {
    private StoreDb db;
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        db = new StoreDb();
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Store");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class StoreDb extends SQLiteOpenHelper {
        StoreDb() { super(MainActivity.this, "alam_store_v5.db", null, 1); }
        @Override public void onCreate(SQLiteDatabase d) {
            d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,category TEXT,unit TEXT,qty REAL DEFAULT 0,min_qty REAL DEFAULT 0,lot TEXT,expiry TEXT,buy REAL DEFAULT 0,sell REAL DEFAULT 0)");
            d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,notes TEXT)");
            d.execSQL("CREATE TABLE suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,notes TEXT)");
            d.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,party TEXT NOT NULL,item_id INTEGER,item_name TEXT,qty REAL,price REAL,total REAL,paid REAL,balance REAL,note TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
            d.execSQL("CREATE TABLE invoice_lines(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER NOT NULL,item_id INTEGER NOT NULL,item_name TEXT NOT NULL,qty REAL NOT NULL,price REAL NOT NULL,line_total REAL NOT NULL)");
        }
        @Override public void onUpgrade(SQLiteDatabase d,int oldV,int newV) {}
    }

    private class Bridge {
        @JavascriptInterface public String list(String table) {
            if (!table.equals("items") && !table.equals("customers") && !table.equals("suppliers") && !table.equals("invoices") && !table.equals("invoice_lines")) return "[]";
            JSONArray a = new JSONArray();
            Cursor c = db.getReadableDatabase().rawQuery("SELECT * FROM " + table + " ORDER BY id DESC", null);
            try {
                while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    for (int i=0;i<c.getColumnCount();i++) {
                        String key=c.getColumnName(i); int type=c.getType(i);
                        Object val=type==Cursor.FIELD_TYPE_INTEGER?c.getLong(i):type==Cursor.FIELD_TYPE_FLOAT?c.getDouble(i):type==Cursor.FIELD_TYPE_NULL?JSONObject.NULL:c.getString(i);
                        o.put(key,val);
                    }
                    a.put(o);
                }
            } catch(Exception ignored) {} finally { c.close(); }
            return a.toString();
        }

        @JavascriptInterface public boolean addItem(String name,String code,String category,String unit,String qty,String minQty,String lot,String expiry,String buy,String sell) {
            if(name==null||name.trim().isEmpty()) return false;
            ContentValues v=new ContentValues(); v.put("name",name);v.put("code",code);v.put("category",category);v.put("unit",unit);
            v.put("qty",number(qty));v.put("min_qty",number(minQty));v.put("lot",lot);v.put("expiry",expiry);v.put("buy",number(buy));v.put("sell",number(sell));
            return db.getWritableDatabase().insert("items",null,v)!=-1;
        }

        @JavascriptInterface public boolean addPerson(String table,String name,String phone,String address,String notes) {
            if((!table.equals("customers")&&!table.equals("suppliers"))||name==null||name.trim().isEmpty()) return false;
            ContentValues v=new ContentValues();v.put("name",name);v.put("phone",phone);v.put("address",address);v.put("notes",notes);
            return db.getWritableDatabase().insert(table,null,v)!=-1;
        }

        @JavascriptInterface public String saveInvoice(String kind,String party,String linesJson,String paidText,String note) {
            if((!kind.equals("بيع")&&!kind.equals("شراء"))||party==null||party.trim().isEmpty()) return "أدخل اسم العميل أو المورد";
            JSONArray lines;
            double paid;
            try { lines=new JSONArray(linesJson); paid=Double.parseDouble(paidText); }
            catch(Exception e){ return "تحقق من الأصناف والدفعة"; }
            if(lines.length()==0) return "أضف صنفاً واحداً على الأقل";
            if(paid<0) return "المبلغ المدفوع لا يمكن أن يكون سالباً";
            SQLiteDatabase d=db.getWritableDatabase(); d.beginTransaction();
            try {
                double total=0, totalQty=0;
                JSONArray checked=new JSONArray(); HashMap<Long,Double> remainingStock=new HashMap<>();
                for(int i=0;i<lines.length();i++) {
                    JSONObject line=lines.getJSONObject(i);
                    long iid=line.getLong("itemId"); double qty=line.getDouble("qty"), price=line.getDouble("price");
                    if(qty<=0||price<0) return "تحقق من كمية وسعر كل صنف";
                    Cursor c=d.rawQuery("SELECT name,qty FROM items WHERE id=?",new String[]{String.valueOf(iid)});
                    if(!c.moveToFirst()){c.close();return "أحد الأصناف لم يعد موجوداً";}
                    String itemName=c.getString(0); double stock=c.getDouble(1); c.close();
                    if(remainingStock.containsKey(iid)) stock=remainingStock.get(iid);
                    if(kind.equals("بيع") && qty>stock) return "المخزون غير كافٍ للصنف: "+itemName+" (المتاح "+stock+")";
                    JSONObject x=new JSONObject(); x.put("itemId",iid);x.put("itemName",itemName);x.put("qty",qty);x.put("price",price);x.put("lineTotal",qty*price);x.put("stock",stock);checked.put(x);
                    remainingStock.put(iid,kind.equals("بيع")?stock-qty:stock+qty);
                    total+=qty*price; totalQty+=qty;
                }
                if(paid>total) return "الدفعة أكبر من إجمالي الفاتورة";
                ContentValues inv=new ContentValues(); inv.put("kind",kind);inv.put("party",party);inv.putNull("item_id");inv.put("item_name",checked.length()+" أصناف");
                inv.put("qty",totalQty);inv.put("price",0);inv.put("total",total);inv.put("paid",paid);inv.put("balance",total-paid);inv.put("note",note);
                long invoiceId=d.insert("invoices",null,inv); if(invoiceId==-1) return "تعذر حفظ الفاتورة";
                for(int i=0;i<checked.length();i++) {
                    JSONObject x=checked.getJSONObject(i); ContentValues line=new ContentValues();
                    line.put("invoice_id",invoiceId);line.put("item_id",x.getLong("itemId"));line.put("item_name",x.getString("itemName"));
                    line.put("qty",x.getDouble("qty"));line.put("price",x.getDouble("price"));line.put("line_total",x.getDouble("lineTotal"));
                    if(d.insert("invoice_lines",null,line)==-1) return "تعذر حفظ تفاصيل الفاتورة";
                    double stock=x.getDouble("stock"), qty=x.getDouble("qty"); ContentValues update=new ContentValues();
                    update.put("qty",kind.equals("بيع")?stock-qty:stock+qty);
                    d.update("items",update,"id=?",new String[]{String.valueOf(x.getLong("itemId"))});
                }
                d.setTransactionSuccessful();
                return "تم حفظ فاتورة "+kind+" رقم "+invoiceId+" بنجاح. عدد الأصناف: "+checked.length()+". الإجمالي: "+total+"، المتبقي: "+(total-paid);
            } catch(Exception e){ return "حدث خطأ أثناء حفظ الفاتورة"; }
            finally { d.endTransaction(); }
        }

        @JavascriptInterface public void printHtml(String html) {
            runOnUiThread(() -> {
                WebView printWeb = new WebView(MainActivity.this);
                printWeb.getSettings().setJavaScriptEnabled(false);
                printWeb.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
                        PrintDocumentAdapter adapter=view.createPrintDocumentAdapter("AlamAlMukhtabirat-Invoice");
                        pm.print("فاتورة عالم المختبرات",adapter,new android.print.PrintAttributes.Builder().setMediaSize(android.print.PrintAttributes.MediaSize.ISO_A4).setResolution(new android.print.PrintAttributes.Resolution("pdf","pdf",300,300)).setMinMargins(android.print.PrintAttributes.Margins.NO_MARGINS).build());
                    }
                });
                printWeb.loadDataWithBaseURL(null,html,"text/HTML","UTF-8",null);
            });
        }

        @JavascriptInterface public String stats() {
            SQLiteDatabase d=db.getReadableDatabase(); JSONObject o=new JSONObject();
            try {
                o.put("items",count(d,"items"));o.put("customers",count(d,"customers"));o.put("suppliers",count(d,"suppliers"));
                Cursor low=d.rawQuery("SELECT COUNT(*) FROM items WHERE qty<=min_qty",null);if(low.moveToFirst())o.put("low",low.getInt(0));low.close();
                Cursor c=d.rawQuery("SELECT COALESCE(SUM(qty*buy),0) FROM items",null);if(c.moveToFirst())o.put("stockValue",c.getDouble(0));c.close();
                Cursor s=d.rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(paid),0),COALESCE(SUM(balance),0) FROM invoices WHERE kind='بيع'",null);
                if(s.moveToFirst()){o.put("salesTotal",s.getDouble(0));o.put("salesPaid",s.getDouble(1));o.put("salesDue",s.getDouble(2));}s.close();
                Cursor p=d.rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(balance),0) FROM invoices WHERE kind='شراء'",null);
                if(p.moveToFirst()){o.put("purchaseTotal",p.getDouble(0));o.put("purchaseDue",p.getDouble(1));}p.close();
            }catch(Exception ignored){}
            return o.toString();
        }
        private int count(SQLiteDatabase d,String t){Cursor c=d.rawQuery("SELECT COUNT(*) FROM "+t,null);int n=0;if(c.moveToFirst())n=c.getInt(0);c.close();return n;}
        private double number(String s){try{return Double.parseDouble(s);}catch(Exception e){return 0;}}
    }
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
