package com.alamalmukhtabirat.v4;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private StoreDb db;
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        db = new StoreDb();
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Store");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class StoreDb extends SQLiteOpenHelper {
        StoreDb() { super(MainActivity.this, "alam_store_v4.db", null, 1); }
        @Override public void onCreate(SQLiteDatabase d) {
            d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,category TEXT,unit TEXT,qty REAL DEFAULT 0,min_qty REAL DEFAULT 0,lot TEXT,expiry TEXT,buy REAL DEFAULT 0,sell REAL DEFAULT 0)");
            d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,notes TEXT)");
            d.execSQL("CREATE TABLE suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,notes TEXT)");
            d.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,party TEXT NOT NULL,item_id INTEGER,item_name TEXT,qty REAL,price REAL,total REAL,paid REAL,balance REAL,note TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        }
        @Override public void onUpgrade(SQLiteDatabase d,int oldV,int newV) {}
    }

    private class Bridge {
        @JavascriptInterface public String list(String table) {
            if (!table.equals("items") && !table.equals("customers") && !table.equals("suppliers") && !table.equals("invoices")) return "[]";
            JSONArray a = new JSONArray();
            Cursor c = db.getReadableDatabase().rawQuery("SELECT * FROM " + table + " ORDER BY id DESC", null);
            try {
                while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    for (int i=0;i<c.getColumnCount();i++) {
                        String key=c.getColumnName(i); int type=c.getType(i);
                        Object val=type==Cursor.FIELD_TYPE_INTEGER?c.getLong(i):type==Cursor.FIELD_TYPE_FLOAT?c.getDouble(i):type==Cursor.FIELD_TYPE_NULL?JSONObject.NULL:c.getString(i);
                        o.put(key,val);
                    }
                    a.put(o);
                }
            } catch(Exception ignored) {} finally { c.close(); }
            return a.toString();
        }

        @JavascriptInterface public boolean addItem(String name,String code,String category,String unit,String qty,String minQty,String lot,String expiry,String buy,String sell) {
            if(name==null||name.trim().isEmpty()) return false;
            ContentValues v=new ContentValues(); v.put("name",name);v.put("code",code);v.put("category",category);v.put("unit",unit);
            v.put("qty",number(qty));v.put("min_qty",number(minQty));v.put("lot",lot);v.put("expiry",expiry);v.put("buy",number(buy));v.put("sell",number(sell));
            return db.getWritableDatabase().insert("items",null,v)!=-1;
        }

        @JavascriptInterface public boolean addPerson(String table,String name,String phone,String address,String notes) {
            if((!table.equals("customers")&&!table.equals("suppliers"))||name==null||name.trim().isEmpty()) return false;
            ContentValues v=new ContentValues();v.put("name",name);v.put("phone",phone);v.put("address",address);v.put("notes",notes);
            return db.getWritableDatabase().insert(table,null,v)!=-1;
        }

        @JavascriptInterface public String saveInvoice(String kind,String party,String itemId,String qtyText,String priceText,String paidText,String note) {
            if((!kind.equals("بيع")&&!kind.equals("شراء"))||party==null||party.trim().isEmpty()) return "أدخل اسم العميل أو المورد";
            long iid; double qty,price,paid;
            try { iid=Long.parseLong(itemId); qty=Double.parseDouble(qtyText); price=Double.parseDouble(priceText); paid=Double.parseDouble(paidText); }
            catch(Exception e){ return "تحقق من الكمية والأسعار والدفعة"; }
            if(qty<=0||price<0||paid<0) return "الكمية يجب أن تكون أكبر من صفر، والقيم المالية غير سالبة";
            SQLiteDatabase d=db.getWritableDatabase(); d.beginTransaction();
            try {
                Cursor c=d.rawQuery("SELECT name,qty FROM items WHERE id=?",new String[]{String.valueOf(iid)});
                if(!c.moveToFirst()){c.close();return "الصنف غير موجود";}
                String itemName=c.getString(0); double stock=c.getDouble(1); c.close();
                if(kind.equals("بيع")&&qty>stock) return "الكمية المطلوبة أكبر من المخزون المتاح ("+stock+")";
                double total=qty*price;
                if(paid>total) return "الدفعة أكبر من إجمالي الفاتورة";
                ContentValues inv=new ContentValues(); inv.put("kind",kind);inv.put("party",party);inv.put("item_id",iid);inv.put("item_name",itemName);
                inv.put("qty",qty);inv.put("price",price);inv.put("total",total);inv.put("paid",paid);inv.put("balance",total-paid);inv.put("note",note);
                if(d.insert("invoices",null,inv)==-1) return "تعذر حفظ الفاتورة";
                ContentValues stockUpdate=new ContentValues();
                stockUpdate.put("qty",kind.equals("بيع")?stock-qty:stock+qty);
                d.update("items",stockUpdate,"id=?",new String[]{String.valueOf(iid)});
                d.setTransactionSuccessful();
                return "تم حفظ فاتورة "+kind+" بنجاح. الإجمالي: "+total+"، المتبقي: "+(total-paid);
            } catch(Exception e){ return "حدث خطأ أثناء حفظ الفاتورة"; }
            finally { d.endTransaction(); }
        }

        @JavascriptInterface public String stats() {
            SQLiteDatabase d=db.getReadableDatabase(); JSONObject o=new JSONObject();
            try {
                o.put("items",count(d,"items"));o.put("customers",count(d,"customers"));o.put("suppliers",count(d,"suppliers"));
                Cursor low=d.rawQuery("SELECT COUNT(*) FROM items WHERE qty<=min_qty",null);if(low.moveToFirst())o.put("low",low.getInt(0));low.close();
                Cursor c=d.rawQuery("SELECT COALESCE(SUM(qty*buy),0) FROM items",null);if(c.moveToFirst())o.put("stockValue",c.getDouble(0));c.close();
                Cursor s=d.rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(paid),0),COALESCE(SUM(balance),0) FROM invoices WHERE kind='بيع'",null);
                if(s.moveToFirst()){o.put("salesTotal",s.getDouble(0));o.put("salesPaid",s.getDouble(1));o.put("salesDue",s.getDouble(2));}s.close();
                Cursor p=d.rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(balance),0) FROM invoices WHERE kind='شراء'",null);
                if(p.moveToFirst()){o.put("purchaseTotal",p.getDouble(0));o.put("purchaseDue",p.getDouble(1));}p.close();
            }catch(Exception ignored){}
            return o.toString();
        }
        private int count(SQLiteDatabase d,String t){Cursor c=d.rawQuery("SELECT COUNT(*) FROM "+t,null);int n=0;if(c.moveToFirst())n=c.getInt(0);c.close();return n;}
        private double number(String s){try{return Double.parseDouble(s);}catch(Exception e){return 0;}}
    }
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
